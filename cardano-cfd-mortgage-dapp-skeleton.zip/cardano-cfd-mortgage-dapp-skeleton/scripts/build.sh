#!/usr/bin/env bash
# Build all Aiken contracts
set -e

aiken build contracts
